import pkg_resources

from draw_tree import plot, DrawTree
import cfg_symbols

pkg_resources.declare_namespace("pygly2.plot")
